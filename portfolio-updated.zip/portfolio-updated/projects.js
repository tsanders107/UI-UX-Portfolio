// Add or edit projects here. Images are relative to index.html.
const projects = [
  {
    title: "Rockwell Landscaping Website",
    role: "Web Design & Front-End Development · 2026",
    description: "Redesigned and developed a website for a landscaping business, focusing on clearer navigation, stronger visual hierarchy, and a more approachable experience. Built with HTML, CSS, and JavaScript; ongoing improvements are in progress.",
    image: "images/landscaping.png",
    imageAlt: "Preview of the Rockwell Landscaping website",
    link: "https://www.rockwellpointe.com/",
    linkText: "View live website",
    secondaryLink: "rockwell-comparison.html",
    secondaryLinkText: "Before & After"
  },
  {
    title: "Hill Air Force Base",
    role: "System-of-Systems UI/UX Design Study · 2026",
    description: "Prototyped a streamlined interface for a complex system-of-systems workflow, focusing on reducing navigation friction and simplifying mission-related interactions. Project details are limited to information approved for public sharing.",
    image: "images/jet.jpg",
    imageAlt: "Aircraft representing the Air Force UX design project",
    link: "",
    linkText: "View project"
  },
  {
    title: "Jewelry Website Concept",
    role: "Website Design Concept · 2026",
    description: "Created a jewelry storefront concept for a friend's small business, using their existing color palette with cleaner layouts, clearer visual hierarchy, and a product-focused browsing experience.",
    image: "images/shop.png",
    imageAlt: "Jewelry website concept preview",
    link: "https://byui-wdd131-02w26.github.io/tas/personal-project/index.html",
    linkText: "View concept"
  },
  {
    title: "Package Design Archive",
    role: "Front-End Class Project · 2026",
    description: "Built a responsive design gallery with JavaScript-generated project cards, focusing on semantic HTML, readable layouts, and keyboard accessibility.",
    image: "images/package-design.png",
    imageAlt: "Package design gallery preview",
    link: "", // Add the correct URL here; the previous URL pointed to the jewelry project.
    linkText: "View project"
  }
];
