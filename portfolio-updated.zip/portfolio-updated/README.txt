PORTFOLIO SETUP
1. Open index.html in a browser (or use VS Code Live Server).
2. Put your original project preview images in images/: landscaping.png, jet.jpg, shop.png, package-design.png.
3. Replace the FOUR PLACEHOLDER after screenshots in images/ with real captures from rockwellpointe.com:
   rockwell-after-home.png
   rockwell-after-about.png
   rockwell-after-reviews.png
   rockwell-after-gallery.png
   Capture the same approximate viewport and scroll region as the corresponding before screenshot.
4. Update email, LinkedIn, Handshake and resume links in index.html. Place your resume at resume.pdf.
5. Update the package design project URL in projects.js (currently deliberately blank).
6. The Hill Air Force Base project description is conservative because details may be confidential; edit only with approved claims.
7. To deploy, upload all files and the images folder together, preserving relative paths.
