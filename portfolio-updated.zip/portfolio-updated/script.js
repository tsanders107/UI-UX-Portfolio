const projectList = document.getElementById('project-list');

function createLink(url, label, secondary = false) {
  const a = document.createElement('a');
  a.className = secondary ? 'card__link card__link--outline' : 'card__link';
  a.href = url;
  a.textContent = label;
  if (/^https?:\/\//i.test(url)) {
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.setAttribute('aria-label', `${label} (opens in a new tab)`);
  }
  return a;
}

function createCard(project, index) {
  const card = document.createElement('article');
  card.className = `card${index % 2 ? ' card--reverse' : ''}`;
  const media = document.createElement('div');
  media.className = 'card__media';
  if (project.image) {
    const img = document.createElement('img');
    img.className = 'card__image';
    img.src = project.image;
    img.alt = project.imageAlt || `${project.title} preview`;
    img.loading = 'lazy';
    media.appendChild(img);
  }
  const body = document.createElement('div');
  body.className = 'card__body';
  const number = document.createElement('span');
  number.className = 'card__number';
  number.textContent = String(index + 1).padStart(2, '0');
  const title = document.createElement('h3');
  title.className = 'card__title';
  title.textContent = project.title;
  const role = document.createElement('p');
  role.className = 'card__meta';
  role.textContent = project.role || '';
  const desc = document.createElement('p');
  desc.className = 'card__description';
  desc.textContent = project.description;
  const actions = document.createElement('div');
  actions.className = 'card__actions';
  if (project.link) actions.appendChild(createLink(project.link, project.linkText || 'View project'));
  if (project.secondaryLink) actions.appendChild(createLink(project.secondaryLink, project.secondaryLinkText || 'Learn more', true));
  body.append(number, title, role, desc, actions);
  card.append(media, body);
  return card;
}

if (projectList) {
  if (typeof projects !== 'undefined' && Array.isArray(projects) && projects.length) {
    projects.forEach((project, index) => projectList.appendChild(createCard(project, index)));
  } else {
    const p = document.createElement('p');
    p.textContent = 'Projects coming soon.';
    projectList.appendChild(p);
  }
}
const year = document.getElementById('year');
if (year) year.textContent = new Date().getFullYear();
