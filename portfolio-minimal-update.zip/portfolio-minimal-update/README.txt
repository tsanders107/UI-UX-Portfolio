This version intentionally keeps the original portfolio layout, typography, colors, and wording. Changes: small spacing/mobile CSS fixes and a Rockwell Before & After link/page.

Your four before screenshots are in images/. The After areas intentionally show placeholders until you provide matching captures. Replace the placeholder divs in rockwell-comparison.html with img tags once the after images are available.

Copy your existing landscaping.png, jet.jpg, shop.png, and package-design.png into images/. Add resume.pdf next to index.html. Your original contact placeholders and project links are unchanged. Open index.html with Live Server.
