const projects = [
  {
    title: "Rockwell Landscaping Website",
    role: "Web Designer Developement, 2026",
    description: "I designed and developed a website for a small landscaping business, focusing on creating a clean, and user-friendly experience. Using HTML, CSS, and JavaScript, I improved the site's visual hierarchy, navigation, and overall functionality. I am still currently working on the website.",
    image: "images/landscaping.png",
    imageAlt: "lawnmower",
    link: "https://www.rockwellpointe.com/",
    linkText: "View Project",
    beforeAfterLink: "rockwell-comparison.html"
  },
  {
    title: "Hill Air Force Base ",
    role: "System-of-Systems UX/UI Design Study 2026 ",
    description: "Spearheaded the rapid prototyping of a modern, intuitive user interface for a complex Air Force System-of-Systems, streamlining pilot training and mission operations. The new UX/UI design removed redundancy in layout and introduced new functionality to improve real-time execution and reducing button clicks by 50%, dramatically decreasing the need for user training, saving the Air Force approximately 500 hours and $63,000 in alternative internal development.",
    image: "images/jet.jpg", imageAlt: "Air Force jet", link: "", linkText: "View Project"
  },
  {
    title: "Jewlery Website", role: "Class Project 2026 ",
    description: "I designed a jewelry website concept for a friend's small business, focusing on creating an modern, and user-friendly experience while maintaining their color scheme. I emphasized clean layouts, visual hierarchy, and a good shopping experience to showcase the jewelry collection.",
    image: "images/shop.png", imageAlt: "Jewlrey website concept",
    link: "https://byui-wdd131-02w26.github.io/tas/personal-project/index.html", linkText: "View Project"
  },
  {
    title: "Package Design Website", role: "Current Class Project 2026 ",
    description: "I designed a package design website concept for a friend's small business, focusing on creating an modern, and user-friendly experience while maintaining their color scheme. I emphasized clean layouts, visual hierarchy, and a good shopping experience to showcase the package designs.",
    image: "images/package-design.png", imageAlt: "Package design website concept",
    link: "https://byui-wdd131-02w26.github.io/tas/personal-project/index.html", linkText: "View Project"
  }
];
